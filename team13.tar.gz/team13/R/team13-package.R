#' team13.
#'
#' @name team13
#' @docType package
#' @import SingleCellExperiment
#' @import scran
#' @import scater
NULL
